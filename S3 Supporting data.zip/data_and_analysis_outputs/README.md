# Supplementary File S3 — Data and analysis outputs

This directory contains the original board logs, supporting data, outputs, and final requirement statements.

## Data provenance

`00_board_logs.csv` contains the original board-log entries used as input for the analyses.

The remaining CSV files contain processed or derived data generated from these source records.

## Files

- `00_board_logs.csv` — original board-log entries used as input.
- `01_reference_table.csv` — mapping of Q1–Q8 to the guiding questions, breakdown labels, practical steps, and coding rules.
- `02_preprocessed_coding_units.csv` — coding units obtained by splitting the board-log entries and attaching the corresponding question metadata.
- `03_collapsed_units_for_patterns.csv` — coding-unit sequences after consecutive repetitions of the same question code were collapsed for transition analysis.
- `04_transition_results.csv` — observed and expected transition counts, observed-to-expected ratios, permutation p values, and pattern strength.
- `05_group_focus.csv` — local group-focus values calculated from neighbouring coding units.
- `06_high_focus_units.csv` — coding units associated with selected high-focus regions used in the interpretation of the group-focus analysis.
- `07_text_versions.csv` — text representations used in the question-fit analysis.
- `08_text_separation_summary.csv` — summary of the TF-IDF and sentence-embedding separation analyses.
- `09_q8_wording_alignment.csv` — lexical-semantic comparison of the original and alternative wording of Q8.
- `10_general_summary.csv` — analysis settings and summary checks.
- `11_team_A_final_requirements.txt` — final requirement statements recorded for Team A.
- `12_team_B_final_requirements.txt` — final requirement statements recorded for Team B.

## Reproducibility

Supplementary File S4 provides the notebook used to reproduce the analyses from 00_board_logs.csv and recreate the figures used in the manuscript.
